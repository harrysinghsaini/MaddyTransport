<?php

return array(
	"" => "none",
	"round" => "round",
	"sticker" => "sticker",
	"rounded-sticker" => "rounded-sticker",
	"square" => "square",
	"rounded-square" => "rounded-square",
	"rounded-hex" => "rounded-hex",
	"octagon" => "octagon",
	"hex" => "hex",
	"frame" => "frame",
	"explode" => "explode",
);